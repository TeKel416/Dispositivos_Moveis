package com.example.minhalista;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MeuViewHolder extends RecyclerView.ViewHolder {
    public MeuViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
