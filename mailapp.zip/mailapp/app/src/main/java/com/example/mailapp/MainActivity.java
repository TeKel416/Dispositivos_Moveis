package com.example.mailapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Seleciona o botão de enviar do layout (tipo = Button, variável = btnEnviar, id do objeto = btnEnviar)
        Button btnEnviar = findViewById(R.id.btnEnviar);

        //Define a função ao clicar o botão de enviar, criando o "ouvidor" de cliques
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Seleciona os campos de texto do layout
                EditText etEmail = findViewById(R.id.etEmail);
                EditText etAssunto = findViewById(R.id.etAssunto);
                EditText etMsg = findViewById(R.id.etMsg);

                //Seleciona os textos dentro dos campos e transforma-os em uma string
                String email = etEmail.getText().toString();
                String assunto = etAssunto.getText().toString();
                String msg = etMsg.getText().toString();

                //Cria uma lista de e-mails com o texto da variável email (porque o EXTRA_EMAIL só aceita listas)
                String[] emails = {email};


                //Criando um objeto Intent "i" que enviará um e-mail com apenas 1 destinatário
                Intent i = new Intent(Intent.ACTION_SENDTO);

                //Define o app como app de e-mail (não vai recomendar outra forma de enviar)
                i.setData(Uri.parse("mailto:"));

                //Coloca as variáveis dentro do Intent i em seus respectivos campos no e-mail
                i.putExtra(Intent.EXTRA_EMAIL, emails);
                i.putExtra(Intent.EXTRA_SUBJECT, assunto);
                i.putExtra(Intent.EXTRA_TEXT, msg);

                //Iniciando a atividade do Intent "i"
                startActivity(i);
            }
        });
    }
}