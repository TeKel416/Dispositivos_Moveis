package com.example.teste1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnEnviar = findViewById(R.id.btnEnviar);
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Obtendo o objeto EditText "etNome" pelo id
                EditText etNome = findViewById(R.id.etNome);
                //Obtendo o texto dentro de "etNome", transformando-o em String e armazenando-o em "nome"
                String nome = etNome.getText().toString();

                //Criando um objeto Intent "i" com o conteúdo dessa classe para ser enviado a "NextActivity"
                Intent i = new Intent(MainActivity.this, NextActivity.class);
                //Colocando a varíavel "nome" com a chave "nome" dentro do Intent "i"
                i.putExtra("nome", nome);
                //Iniciando a atividade do Intent "i"
                startActivity(i);
            }
        });
    }
}