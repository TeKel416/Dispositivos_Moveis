package com.example.teste1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class NextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        //Obtendo o objeto Intent "i"
        Intent i = getIntent();
        //Obtendo a String dentro do Intent "i" através da chave "nome"
        String nome = i.getStringExtra("nome");

        //Obtendo o objeto TextView "tvNome" pelo id
        TextView tvNome = findViewById(R.id.tvNome);
        //Definindo o texto de "tvNome" como a variável "nome"
        tvNome.setText(nome);
    }
}